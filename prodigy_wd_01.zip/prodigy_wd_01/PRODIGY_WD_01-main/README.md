# PRODIGY_WD_01
Task 1 as an intern in prodigy infotech
I have created an interactive navigation menu that changes colour and style when scrolled or when hovered over a menu item which displays and shows various tourist spots in Bangalore with pictures . The navigation menu has a fixed position and is visible on all pages. I have enclosed html,css,java script code seperately .
